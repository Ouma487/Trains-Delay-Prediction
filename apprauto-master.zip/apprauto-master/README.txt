######## Projet Cours ApprAuto 2023/2024 ########

#Contributeurs : 
                - Moetez Lahdhiri, moetez.lahdhiri@student-cs.fr
                - Mohamed Aziz Triki, aziz.triki@student-cs.fr
                - Oumaima Chater, oumaima.chater@student-cs.fr
                - Abdelillah Bourchad, abdelillah.bourchad@student-cs.fr

#Fichiers : 
                - datasetFirstAnalysis.ipynb : Premières analyses de données
                - mouvements-sociaux-depuis-2002.csv : Dataset externe mouvements sociaux
                - objets-trouves-restitution.csv : Dataset externe objets trouvés
                - restriction_3_optimisation_multimodel.ipynb : Prédictions retard moyen sous niveau de restriction 3
                - trainOnAllDatasets.ipynb : Fusionner le dataset principal avec les datasets externes et entrainer les modeles avec les nouvelles features


